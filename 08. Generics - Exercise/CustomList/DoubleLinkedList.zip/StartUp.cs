﻿using System;

namespace CustomList
{
    class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
